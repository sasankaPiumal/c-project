/*  
KADSE201F-059
KADSE201F-060
KADSE201F-061
	
*/

#include<iostream>
#include<string>
#include<iomanip>
#include<fstream>
using namespace std;
 class Vehical{
	protected:
		int vType, a,b,q,e;
		double w;
		char ch; //select brand & type;
		float DailyRate;  //daily rent amount;
	public:
	
	
	 Vehical() //--BASE CLASS CONSTRUCTOR.
		{  cout<<"\n\t\t>>>>>___AURORA LUXURY VEHICLES___<<<<<"<<endl<<endl;
			cout<<"  \t\t\t******************** \t \t "<<endl;
			cout<<"  \t\t\t**  OUR VEHICLES  **\t \t "<<endl;
			cout<<"  \t\t\t**________________**\t \t "<<endl;
			cout<<"  \t\t\t********************\t \t "<<endl;
			
			cout<<"\n\t\t 1) Cars \n\t\t 2) Vans \n\t\t 3) Heavy \n\t\t 4) Exit from type list \n";
		}
		
		void select()
		{
			cout<<" \n\n Enter what type of vehicle do you want \n select from (1,2,3) \t :  "; cin>>vType;
			whenSelect();
		}
		void whenSelect()
		{
			switch(vType) //select vehical type...
			{
				case 1:	
					  {
						carType();
						break;
					  }
				case 2:
					  {
						vanType();
						break;
				      }
				case 3:
					  {
						havyType();
						break;
					  }
				default:
					  {
						cout<<" \n Invalid Number ....Please Try Again.. \n";
					  }
			}
				
		}	
		
	void carType();
	void Brand();
	float DRate();
	
	void vanType();
	void Brand(int a);
	float DRate(int b);
	
	void havyType();
	void Brand(int a,double w);
	float DRate(int q,int e);	
	 
	 ~Vehical()
	 {
	 	// destructor calling.
	 	ofstream mm("memo.txt");
	     for(int h=1; h<=3; h++)
	 	{
	 		mm<<vType<<endl;
	 		mm<<ch<<endl;
	 		mm<<DailyRate<<endl;
		 }
	 	
	 	mm.close();
		
	 	
	 }
};

void Vehical :: carType()
{
	Brand();
	cout<<" \nTo give up this  selection enter 0.";
	cout<<" \n Enter Your Prefer Car  Brand & Type : "; cin>>ch;
	DRate();
	
}
void Vehical ::Brand()
	{
	
	
	cout<<"  _______________________________________________________________________ "<<endl;
	cout<<" *|                             |                                       |*"<<endl;
	cout<<" *|            BRAND            |                 MODEL                 |*"<<endl;
	cout<<" *|_____________________________|_______________________________________|*"<<endl;
	cout<<" *|                             |                                       |*"<<endl;
	cout<<" *|      Mercedes-benz          |   A) CLA 300                          |*"<<endl;
	cout<<" *|                             |   B) Convertable                      |*"<<endl;
	cout<<" *|                             |   C) SUV                              |*"<<endl;
	cout<<" *|                             |   D) Sport                            |*"<<endl;
	cout<<" *|                             |   E) G Class-GF63                     |*"<<endl;
	cout<<" *|                             |   F) S Class AMG                      |*"<<endl;
	cout<<" *|_____________________________|_______________________________________|*"<<endl;
	cout<<" *|                             |                                       |*"<<endl;
	cout<<" *|      BMW                    |   G) Normal type                      |*"<<endl;
	cout<<" *|                             |   H) 730ld                            |*"<<endl;
	cout<<" *|                             |   I) SUV                              |*"<<endl;
	cout<<" *|                             |   J) Sport                            |*"<<endl;
	cout<<" *|_____________________________|_______________________________________|*"<<endl;
	cout<<" *|                             |                                       |*"<<endl;
	cout<<" *|      Toyota                 |   K) ALLION                           |*"<<endl;
	cout<<" *|                             |   L) Primio                           |*"<<endl;
	cout<<" *|                             |   M) SUV                              |*"<<endl;
	cout<<" *|                             |   N) suv(V8)                          |*"<<endl;
	cout<<" *|_____________________________|_______________________________________|*"<<endl;
	cout<<" *|                             |                                       |*"<<endl;
	cout<<" *|      Nissan                 |   O) leaf                             |*"<<endl;
	cout<<" *|                             |   P) X-trail                          |*"<<endl;
	cout<<" *|_____________________________|_______________________________________|*"<<endl;
	cout<<" *************************************************************************"<<endl;                                                                  
	
	
	cout<<endl<<endl;
		
	}
	float Vehical :: DRate()
	{
	     if(ch =='A'|| ch=='a')
	     {
	     return DailyRate = 8000;
		 }
		 else if(ch =='B'|| ch=='b')
		 {
		 return	DailyRate = 14000;
		 }
		 else if(ch =='C'|| ch=='c')
		 {
		 return	DailyRate = 12000;
		 }
		 else if(ch =='D'|| ch=='d')
		 {
		 return	DailyRate = 17000;
		 }
		 else if(ch =='E'|| ch=='e')
		 {
		 return	DailyRate = 20000;
		 }
		 else if(ch =='F'|| ch=='f')
		 {
		 return	DailyRate = 26000;
		 }
		 else if(ch =='G'|| ch=='g')
		 {
		 return	DailyRate = 5000;
		 }
		 else if(ch =='H'|| ch=='h')
		 {
		 return	DailyRate = 5000;
		 }
		 else if(ch =='I'|| ch=='i')
		 {
		 return	DailyRate = 15000;
		 }
		 else if(ch =='J'|| ch=='j')
		 {
		 return	DailyRate = 12000;
		 }
		 else if(ch =='K'|| ch=='k')
		 {
		 return	DailyRate = 5000;
		 }
		 else if(ch =='L'|| ch=='l')
		 {
		 return	DailyRate = 5000;
		 }
		 else if(ch =='M'|| ch=='m')
		 {
		 return	DailyRate = 15000;
		 }else if(ch =='N'|| ch=='n')
		 {
		 return	DailyRate = 17000;
		 }
		 else if(ch =='O'|| ch=='o')
		 {
		 return	DailyRate = 5000;
		 }
		 else if(ch =='P'|| ch=='p')
		 {
		 return	DailyRate = 7000;
        }
        else
        {
        	cout<<"..... \n";
		}
	}
	
	void Vehical :: vanType()
	{
		 Brand( b);
		 cout<<"\n To give up this  selection enter 0.";
		 cout<<" \n Enter Your Prefer Van  Brand & Type : "; cin>>ch;
		 DRate(b);
	}
	void Vehical :: Brand(int b)
	{ 
		a = b;
	cout<<" _______________________________________________________________________"<<endl;
	cout<<"*|                             |                                       |*"<<endl;
	cout<<"*|         BRAND               |                 MODEL                 |*"<<endl;
	cout<<"*|_____________________________|_______________________________________|*"<<endl;
	cout<<"*|                             |                                       |*"<<endl;
	cout<<"*|         Toyota              |   Q) HIACE                            |*"<<endl;
	cout<<"*|                             |   R) Dolphin                          |*"<<endl;
	cout<<"*|                             |   S) KDH High Roof                    |*"<<endl;
	cout<<"*|_____________________________|_______________________________________|*"<<endl;                           
	cout<<"*|                             |                                       |*"<<endl;
	cout<<"*|         Nissan              |   T) Vanette                          |*"<<endl;
	cout<<"*|                             |   U) NV 200                           |*"<<endl;
	cout<<"*|                             |   V) Clipper                          |*"<<endl;
	cout<<"*|_____________________________|_______________________________________|*"<<endl;                                                                   
	cout<<"*|                             |                                       |*"<<endl;
	cout<<"*|         Mitsubishi          |   W) Minicab                          |*"<<endl;
	cout<<"*|                             |   X) Micro MPV Juniort                |*"<<endl;
	cout<<"*|_____________________________|_______________________________________|*"<<endl;
	cout<<"*************************************************************************"<<endl;
	                                                                
     cout<<endl<<endl;
				
	}
	float Vehical :: DRate(int b)
	{ 
		a=b;
	     if(ch =='Q'|| ch=='q')
	     {
	     return DailyRate = 12000;
		 }
		 else if(ch =='R'|| ch=='r')
		 {
		 return	DailyRate = 6000;
		 }
		 else if(ch =='S'|| ch=='s')
		 {
		 return	DailyRate = 13000;
		 }
		 else if(ch =='T'|| ch=='t')
		 {
		 return	DailyRate = 6000;
		 }
		 else if(ch =='U'|| ch=='u')
		 {
		 return	DailyRate = 5000;
		 }
		  else if(ch =='V'|| ch=='v')
		 {
		 return	DailyRate = 5000;
		 }
		  else if(ch =='W'|| ch=='w')
		 {
		 return	DailyRate = 5000;
		 }
		  else if(ch =='X'|| ch=='x')
		 {
		 return	DailyRate = 7000;
		 }
        else
        {
        	cout<<"..... \n";
		}
	}
	
	void Vehical :: havyType()
	{
		Brand(a, w);
		cout<<" \n To give up this  selection enter 0.";
		cout<<" \n Enter Your Prefer Heavy  Brand & Type : "; cin>>ch;
		 DRate(q,e);
	}
	void Vehical :: Brand(int a,double w)
	{
		this ->a=a;
		this ->w=w;
		
	cout<<" _______________________________________________________________________ "<<endl;
	cout<<"*|                             |                                       |*"<<endl;
	cout<<"*|            BRAND            |                 MODEL                 |*"<<endl;
	cout<<"*|_____________________________|_______________________________________|*"<<endl;
	cout<<"*|                             |                                       |*"<<endl;
	cout<<"*|         Mercedes-benz       |   Y) Luxury Traveling Bus             |*"<<endl;
	cout<<"*|                             |                                       |*"<<endl;
	cout<<"*|_____________________________|_______________________________________|*"<<endl;
	cout<<"*|                             |                                       |*"<<endl;                           
	cout<<"*|                             |                                       |*"<<endl;
	cout<<"*|         Volvo               |   Z) Luxury Traveling Bus             |*"<<endl;
	cout<<"*|                             |                                       |*"<<endl;
	cout<<"*|_____________________________|_______________________________________|*"<<endl;
	cout<<"*************************************************************************"<<endl;
	}
	float Vehical :: DRate(int q,int e)
	{
	     
		a =q;
		b=e;
		
	     if(ch =='A'|| ch=='a')
	     {
	     return DailyRate = 29000;
		 }
		 else if(ch =='Z'|| ch=='z')
	     {
	     return DailyRate = 35000;
		 }
		 else
        {
        	cout<<"..... \n";
		}
    }
//=====================================================================================================================================

class Dealer {
	protected:
		int dealerID;
		string dealerName;
		char cAddress[100]; // Company Address
		char cPhone[10]; // Conpany Phone No
		
	public:
		void getFromDealer()
		{
			cout<<" \n \t###___ENTER DEALER & COMPANY DETAILS HERE___### \n\n";
			cout<<"Enter dealer ID No : "; cin>>dealerID;
			cout<<"Enter dealer Name : "; cin>>dealerName;
			cout<<"Enter Company Address : "; cin>>cAddress;
			cout<<"Enter Company Phone No : "; cin>>cPhone;
		}
		void displayDealerCompany()
		{
			cout<<"\t \n ####___DEALER & COMPANY DETAILS___#### \n\n"<<endl;
			cout<<"Dealer ID No     : "<<dealerID<<endl;
			cout<<"Dealer Name      : "<<dealerName<<endl;
			cout<<"Company Address  : "<<cAddress<<endl;
			cout<<"Company Phone No : "<<cPhone<<endl;
		}
		~Dealer()
		{
			ofstream deal("Dealer.txt");
	 		deal<<dealerID<<endl;
	 		deal<<dealerName<<endl;
	 		deal<<cAddress<<endl;
	 		deal<<cPhone<<endl;
	 	
	 	deal.close();
		}
};

//==================================================================================================================================
class Customer {
	protected:
		int custID,CustAge,lendDays;
		string CustName;
		char CustAddress[100];
		char CustPhone[10];
	public:
		void getFromCust()
		{
			cout<<" \n\t###___ENTER CUSTOMERS DETAILS___###\n\n";
			if(CustAge >18 ||  CustAge <65)
			   {
				 	cout<<"Enter customer ID No : ";    cin>>custID;
				  	cout<<"Enter Customer Name : ";     cin>>CustName;
			     	cout<<"Enter your Age : "; 		    cin>>CustAge;
				 	cout<<"Enter Customer Address : ";  cin>>CustAddress;
				 	cout<<"Enter Customer Phone No : "; cin>>CustPhone;
				 
			   }
		   else
		 	  {
		  			cout<<"You are unable to get rent a vehicle ,because we are not accept your age limit. \n";
		  	  }	
		
		}
		
	void CustDisplay()
		{ 
		cout<<"\t \n####___CUSTOMERS DETAILS___#### \n\n";
		  	cout<<"Customer ID No : "   <<custID<<endl;
			cout<<"Customer Name : "    <<CustName<<endl;
			cout<<"Customer Age : "     <<CustAge<<endl;
			cout<<"Customer Address : " <<CustAddress<<endl;
			cout<<"Customer Phone No : "<<CustPhone<<endl;
	    }
	    
	    ~Customer()
			{
				ofstream custom("CUSTOMER.txt");
	 			custom<<custID<<endl;
	 			custom<<CustName<<endl;
	 			custom<<CustAddress<<endl;
	 			custom<<CustPhone<<endl;
	 			custom.close();
		    }
		
	
};
//====================================================================================================================================

class Vehical_Customer : public Vehical, public Customer,public Dealer{
		protected:
		int noOfVehicle;
		float changeStt1,changeStt2; // to change tatic variable;      //DailyRate ; lendDays;
		double basicDailyPrice,sum;
		
	public:
		int days=0;	 
		static float dailyTax,maxDayTax;
	
	
		void longAlalysiing()
		{
		 	cout<<"\n\n!!!( 1 Customer can get only 3 vehicles at once...Select from following list ) !!! n";
		 	cout<<"\n\n How many vehicles do you want : "; cin>>noOfVehicle;
			
			//select();
			calDailyPrice();
    	}
    	
    	static float changeStatic(float changeStt1,float changeStt2)
    	{
    		dailyTax =changeStt1;
    		maxDayTax = changeStt2;
		}	
	
	void calDailyPrice();	
	
	void normalShow()
			{
				CustDisplay();
				cout<<"\n"<<endl;
				displayDealerCompany();
				cout<<"Final Bill  Rs   : "<<sum<<".00"<<endl;
			}
			
			void finalInvoice(); 	
};

void Vehical_Customer ::calDailyPrice()  
{
     	  if(noOfVehicle>=1 && noOfVehicle<=3)
		 		  
			   {	
		 			while(noOfVehicle >=1 )
						{	    
							select();			
							cout<<" \nEnter lend days :" ; cin>>lendDays;
				         				
					    	{
						    	if(lendDays < 5)
							   		{
										basicDailyPrice = DailyRate * lendDays ;
									 
									}
								else if(lendDays>=5 && lendDays<=10)
									{
										basicDailyPrice = DailyRate * lendDays  + dailyTax;
										
									}
								else if(lendDays > 10 && lendDays<=15)
									{
										basicDailyPrice = DailyRate * lendDays  + maxDayTax;
										
									}
								else
						    		{
										cout<<" *****WE ARE UNABLE TO GIVE OUR VEHICLES MORE THAN FIFTEEN DAYS....***** \n ";
						    		}	
						    	
									sum = sum +basicDailyPrice;
									days =days +lendDays;	
									noOfVehicle--;
					    	}								 
						        
				       }	                  
	        }
			  
		    else
	           {
	      	    	cout<<" \n";
		  	   }
		    		
}
void Vehical_Customer :: finalInvoice()
{
	cout<<"\t              ********************************************                    "<<endl;
	cout<<"\t                *  VEHICAL RENTAL - CUSTOMER INVOICE   *                      "<<endl;
	cout<<"\t              ********************************************                    "<<endl;
	cout<<"\t   _______________________________________________________________________________"<<endl;
	cout<<"\t   | Customer Name :"<<"-----------------------|"<<setw(10)<<CustName       <<"  |"<<endl;
	cout<<"\t   | Customer ID :  "<<"-----------------------|"<<setw(10)<<custID         <<"  |"<<endl;
	cout<<"\t   | Customer Phone No:"<<"--------------------|"<<setw(10)<<custID         <<"  |"<<endl;
	cout<<"\t   | Dealer Name   :"<<"-----------------------|"<<setw(10)<<dealerName     <<"  |"<<endl;
    cout<<"\t   | Dealer ID   :  "<<"-----------------------|"<<setw(10)<<dealerID       <<"  |"<<endl;
    cout<<"\t   | Company Phone No :"<<"--------------------|"<<setw(10)<<cPhone         <<"  |"<<endl;
	cout<<"\t   | Vehicle Type :"<<"------------------------|"<<setw(10)<<vType          <<"  |"<<endl;
	cout<<"\t   | Number Of Days :"<<"----------------------|"<<setw(10)<<days           <<"  |"<<endl;
	cout<<"\t   | Your Rental Amount is Rs :"<<"--------    |   "   <<sum<<".00 "             <<endl;
	cout<<"\t   |_____________________________________________________________________________"<<endl;
	cout<<"\t        1) Cars \t  2) Vans \t 3) Heavy \n"<<endl;                                   
	
	cout<<"\t  Total Rental Amount is Rs :"<<"-------------"<<setw(10)<<sum<<".00         "<<endl;
	cout<<"\t  ____________________________________________________________________________"<<endl;
	cout<<"\t  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%"<<endl;
	cout<<"\t  %     You are adviced to pay up the amount before due date                 %"<<endl;
	cout<<"\t  %     Otherwise penelty fee will be applied                                %"<<endl;
	cout<<"\t  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%"<<endl;
	
	
	
	
}

float Vehical_Customer :: dailyTax = 100;
float Vehical_Customer :: maxDayTax = 150;

int main()
{
	
	//Vehical_Customer :: dailyTax = 100;
	//Vehical_Customer :: maxDayTax = 150;
	
	Vehical_Customer vc1;
	vc1.longAlalysiing();
	
	vc1.getFromCust();
	vc1.getFromDealer();
	cout<<"\n";
	
	vc1.calDailyPrice();
	cout<<"\n";
	
	vc1.changeStatic(100,150);
	vc1.calDailyPrice();
	vc1.normalShow();
	cout<<endl<<endl;
	vc1.finalInvoice();
			
}


	
